(!) THIS FOLDER SHOULD BE PLACED AT PROJECT ROOT: 
"./Messy-Folder-Organizer/mfo_config"

1- Edit the configuration files as you want.

2- Uncomment this line from "main.py":
   seed.update()

3- Run main.py

4- Before compiling, comment this line again:
   # seed.update()
